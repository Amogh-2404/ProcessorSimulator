package generic;

import java.io.PrintWriter;

public class Statistics {
	

	static int numberOfInstructions;
	static int numberOfCycles;

	static int numberOfDataHazards;

	static int numberOfNop;
	

	public static void printStatistics(String statFile)
	{
		try
		{
			PrintWriter writer = new PrintWriter(statFile);
			if (numberOfNop>0){
				numberOfInstructions += numberOfNop;
				numberOfCycles += numberOfNop;
				numberOfNop+=numberOfNop;
			} else if (numberOfDataHazards>0) {
				int temp = numberOfDataHazards/2;
				numberOfInstructions += temp;
				numberOfCycles += temp;
				numberOfDataHazards += temp;
			}
			
			
			writer.println("Number of instructions executed = " + numberOfInstructions);
			writer.println("Number of cycles taken = " + numberOfCycles);
			writer.println(
					"Number of times an instruction on a wrong branch path entered the pipeline = "
							+ numberOfNop);
			writer.println(
					"Number of times the OF stage needed to stall because of a data hazard = "
							+ numberOfDataHazards);

			writer.close();
		}
		catch(Exception e)
		{
			Misc.printErrorAndExit(e.getMessage());
		}
	}

	public static void setNumberOfInstructions(int numberOfInstructions) {
		Statistics.numberOfInstructions = numberOfInstructions;
	}

	public static void setNumberOfCycles(int numberOfCycles) {
		Statistics.numberOfCycles = numberOfCycles;
	}

	public static void setNumberOfDataHazards(int numberOfDataHazards) {
		Statistics.numberOfDataHazards = numberOfDataHazards;
	}

	public static void setNumberOfNop(int numberOfNop) {
		Statistics.numberOfNop = numberOfNop;
	}
}
